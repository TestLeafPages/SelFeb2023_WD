package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;


public class HomePage1 extends BaseClass {
	
		
   @Then ("Homepage is displayed")
   public HomePage1 verifyHomePage() {
	   System.out.println(getDriver().getTitle());	   
	return this;
  }

	public MyHomePage1 clickOnCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage1();
		
	}
		
public LoginPage1 logoutButton() {
	getDriver().findElement(By.className("decorativeSubmit")).click();	
	return new LoginPage1();
	
	
	}
}
