package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import baseclass.BaseClass;

public class CreateLeadPage1 extends BaseClass{

	
		
	public CreateLeadPage1 enterCompanyName(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
	return this;
	
	}


	public CreateLeadPage1 enterFirstName(String fName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	return this;
	}


	public CreateLeadPage1 enterLastName(String lName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	return this;
	}


	public ViewLead clickOnCreateLeadButton() {
		getDriver().findElement(By.name("submitButton")).click();		
		return new ViewLead();
	}
}
