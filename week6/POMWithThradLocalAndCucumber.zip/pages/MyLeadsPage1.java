package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import baseclass.BaseClass;






public class MyLeadsPage1 extends BaseClass{

	
	public CreateLeadPage1 clickOnCreateLead() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage1() ;
	}
	
	
	
}
