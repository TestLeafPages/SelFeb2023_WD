package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import baseclass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;


public class LoginPage1 extends BaseClass{
	 	
	//constructor
	//normal method
	@Given("Enter the username as {string}")
	public LoginPage1 enterUserName(String username) throws InterruptedException {
		getDriver().findElement(By.id("username")).sendKeys(username);	
			return this;
	}

	@Given ("Enter the password as {string}")
	public LoginPage1 enterPassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this;
	}

	@When("Click the Login button")
	public HomePage1 clickOnLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage1();
	}
	
	
	
	
	
}
