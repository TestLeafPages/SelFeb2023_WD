package runner;

import baseclass.BaseClass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(features={"src/test/java/features/F01_Login.feature"},
glue="pages",
publish=true,
monochrome=true)

public class LoginRunner extends BaseClass{

}
