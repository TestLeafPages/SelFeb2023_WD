package testcase;

import org.testng.annotations.Test;

import baseclass.BaseClass;
import pages.LoginPage;
import pages.LoginPage1;

public class TC_001 extends BaseClass{

	@Test
	public void loginData() throws InterruptedException { 
		
		System.out.println(driver);		
		LoginPage1 lp= new LoginPage1();
		lp.enterUserName("Demosalesmanager").enterPassword("crmsfa")
		.clickOnLoginButton().verifyHomePage();
	}
}
