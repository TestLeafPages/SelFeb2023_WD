package baseclass;

public class Payment {

	public static void main(String[] args) {
		
		Encapsulation c=new Encapsulation();
		System.out.println(c.getCcv());
		System.out.println("Old Pwassword :" +c.getPwd());
		c.setPwd(678);
		System.out.println("New password : " +c.getPwd());
		
	}

}
