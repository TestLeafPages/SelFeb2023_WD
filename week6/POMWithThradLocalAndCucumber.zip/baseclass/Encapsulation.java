package baseclass;

public class Encapsulation {

	private final int ccv=123;
	private int pwd=2345;
	
	public final int x=10;//constant value

	public int getCcv() {
	//x=20; is not possible
		return ccv;
	}


	public int getPwd() {
		return pwd;
	}


	public void setPwd(int pwd) {
		this.pwd = pwd;
	}
	
	
}
